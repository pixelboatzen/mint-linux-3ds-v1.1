
#ifndef UI_H
#define UI_H
#include <3ds.h>

void ui_init(void);
void ui_exit(void);
void ui_handle_input(u32 kDown, u32 kHeld, const touchPosition* touch);
void ui_draw(void);

#endif // UI_H
