
#include "ui.h"
#include <citro2d.h>
#include <citro2d.h>
#include <stdio.h>
#include "assets.h"
#include "apps.h"

static int selected = 0;
static float cursor_anim = 0.0f;

void ui_init(void) {
    // load assets
    assets_load();
}

void ui_exit(void) {
    assets_unload();
}

void ui_handle_input(u32 kDown, u32 kHeld, const touchPosition* touch) {
    if (kDown & KEY_DOWN) selected = (selected + 1) % 4;
    if (kDown & KEY_UP) selected = (selected + 3) % 4;
    if (kDown & KEY_A) {
        if (selected == 0) {
            // Terminal (not a full shell, simulated)
            consoleClear();
            printf("Terminal: feature demo\\nPress B to return\\n");
        } else if (selected == 1) {
            apps_show_list();
        } else if (selected == 2) {
            // Settings (toggle theme)
            assets_toggle_theme();
        } else if (selected == 3) {
            aptExit();
        }
    }
    if (kDown & KEY_B) {
        // clear bottom console and return to menu
        consoleClear();
    }
}

void ui_draw(void) {
    C2D_TargetClear(topTarget, C2D_Color32(220, 255, 230, 255));
    // background
    C2D_DrawImageAt(assets.bg, 0, 0, 0.0f);
    // draw icons and menu
    const char *labels[4] = {"Terminal", "Apps", "Settings", "Power"};
    for (int i=0;i<4;i++) {
        float x = 24.0f;
        float y = 40.0f + i*48.0f;
        C2D_DrawText(&assets.font, C2D_AtBaseline, x+40, y+16, 0.5f, labels[i], NULL);
        C2D_DrawImageAt( (i==0?assets.icon_terminal:(i==1?assets.icon_apps:(i==2?assets.icon_settings:assets.icon_power)) ), x, y, 0.0f);
    }
    // cursor highlight
    float cy = 40.0f + selected*48.0f;
    C2D_DrawRect(C2D_Rect(8, cy-4, 240, 40), 0.0f);
}
