#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>

#define SCREEN_WIDTH 400
#define SCREEN_HEIGHT 240

int main(void) {
    // Initialisation du système 3DS
    gfxInitDefault();
    consoleInit(GFX_BOTTOM, NULL);

    // Initialisation Citro2D
    C2D_Init();
    C2D_Prepare();

    // Création de la target pour le top screen
    C2D_Target* topTarget = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);

    // Chargement d'une font par défaut
    C2D_Font font;
    C2D_FontLoadDefault(&font);

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();

        if (kDown & KEY_START) break; // Quitter avec START

        // Commencer le rendu
        C2D_SceneBegin(topTarget);
        C2D_Clear(C2D_Color32(0, 0, 255, 255)); // fond bleu

        // Affichage d'un texte
        C2D_DrawText(&font, 0, 50.0f, 100.0f, 0.5f, 1.0f, 1.0f);

        // Fin du rendu et swap
        C2D_SceneEnd();
        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }

    // Libération des ressources
    C2D_Fini();
    gfxExit();
    return 0;
}
