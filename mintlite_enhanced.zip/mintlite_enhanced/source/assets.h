
#ifndef ASSETS_H
#define ASSETS_H
#include <citro2d.h>

typedef struct {
    C2D_SpriteSheet sheet;
    C2D_Image bg;
    C2D_Image icon_terminal;
    C2D_Image icon_apps;
    C2D_Image icon_settings;
    C2D_Image icon_power;
    C2D_TextBuf textBuf;
    C2D_Font font;
} assets_t;

extern assets_t assets;

void assets_load(void);
void assets_unload(void);
void assets_toggle_theme(void);

#endif // ASSETS_H
