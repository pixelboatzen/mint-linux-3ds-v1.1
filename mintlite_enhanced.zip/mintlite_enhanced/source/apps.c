
#include "apps.h"
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <3ds.h>

#define APPS_DIR "sdmc:/3ds/MintLite/apps/"

static char **app_list = NULL;
static int app_count = 0;

void apps_init(void) {
    // scan directory for .3dsx files
    DIR *d = opendir("/3ds/MintLite/apps/");
    if (!d) {
        printf("No apps directory found (sdmc:/3ds/MintLite/apps/). Create it and add .3dsx files.\\n");
        return;
    }
    struct dirent *entry;
    while ((entry = readdir(d)) != NULL) {
        if (strstr(entry->d_name, ".3dsx")) {
            app_list = realloc(app_list, sizeof(char*)*(app_count+1));
            app_list[app_count] = strdup(entry->d_name);
            app_count++;
        }
    }
    closedir(d);
    printf("Found %d apps.\\n", app_count);
}

void apps_exit(void) {
    for (int i=0;i<app_count;i++) free(app_list[i]);
    free(app_list);
    app_list = NULL;
    app_count = 0;
}

void apps_show_list(void) {
    // simple console listing for demo
    consoleClear();
    printf("Installed apps:\\n");
    for (int i=0;i<app_count;i++) {
        printf("%s\\n", app_list[i]);
    }
    printf("\\nPress B to return.\\n");
}
