
#ifndef APPS_H
#define APPS_H

void apps_init(void);
void apps_exit(void);
void apps_show_list(void);

#endif // APPS_H
