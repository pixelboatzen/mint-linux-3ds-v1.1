
# MintLite Enhanced - Source Project (Citro2d UI)
This project is an enhanced version of MintLite for Old 3DS (source only).

## What's included
- citro2d-based UI (main menu, icons, theme)
- apps scanner (reads sdmc:/3ds/MintLite/apps/ for .3dsx files)
- placeholder assets (gfx/*.png)
- Makefile and build script (requires devkitPro + citro2d)

## Build
1. Install devkitPro (devkitARM) and libctro2d/citro2d via dkp-pacman.
2. Set DEVKITPRO env var if not automatic.
3. Run `./build.sh` to compile.
4. Copy resulting `.3dsx` to `sdmc:/3ds/` and run via Homebrew Launcher or convert to .cia with makerom.

## Notes
- Some assets (spritesheet.bin, font data) must be prepared or replaced by your own assets. The included PNGs and simple font are placeholders.
- This is a lightweight launcher — tune code for memory/perf if needed.
