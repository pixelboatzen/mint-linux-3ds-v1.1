
#!/bin/sh
set -e
echo "Building MintLite Enhanced..."
if [ -z "$DEVKITPRO" ]; then
  echo "DEVKITPRO not set. Trying common locations..."
  for p in /opt/devkitpro /usr/local/devkitpro "$HOME/devkitpro"; do
    if [ -d "$p" ]; then
      export DEVKITPRO="$p"
      echo "Using DEVKITPRO=$DEVKITPRO"
      break
    fi
  done
fi

if [ -z "$DEVKITPRO" ]; then
  echo "ERROR: DEVKITPRO not found. Please install devkitPro and set DEVKITPRO."
  exit 1
fi

make clean
make

echo "Build complete. Check build/ for output (.3dsx / .elf)."
